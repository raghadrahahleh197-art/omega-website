// Slider + language toggle + contact form (basic)
document.addEventListener('DOMContentLoaded', function() {
  // Slider
  const slides = Array.from(document.querySelectorAll('.slider img'));
  const dots = Array.from(document.querySelectorAll('.dot'));
  let idx = 0;
  let autoplay = true;
  const show = (i) => {
    slides.forEach(s => s.style.display = 'none');
    dots.forEach(d => d.classList.remove('active'));
    slides[i].style.display = 'block';
    dots[i].classList.add('active');
  };
  show(0);
  document.getElementById('next').addEventListener('click', function(){ idx = (idx+1)%slides.length; show(idx); });
  document.getElementById('prev').addEventListener('click', function(){ idx = (idx-1+slides.length)%slides.length; show(idx); });
  dots.forEach((d, i) => d.addEventListener('click', () => { idx=i; show(i); }));

  setInterval(()=>{ if(autoplay){ idx=(idx+1)%slides.length; show(idx); } }, 3500);

  // language toggle (simple redirect)
  document.getElementById('langToggle').addEventListener('click', function(){
    const path = window.location.pathname;
    if(path.includes('/en/')) {
      window.location.href = window.location.pathname.replace('/en/','/');
    } else {
      window.location.href = '/en/';
    }
  });

  // contact form
  const form = document.querySelector('form.contact');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      alert('✅ شكراً! تم إرسال الطلب (نموذج تجريبي).');
      form.reset();
    });
  }
});
